import {
  MdDashboard,
  MdLibraryBooks,
  MdOutlineAnalytics,
  MdReport,
  MdUpdate,
  MdUpload,
} from "react-icons/md";
import { FaCertificate, FaFileAlt, FaLink } from "react-icons/fa";

const menuConfig = [
  {
    title: "Dashboard",
    icon: MdDashboard,
    path: "/dashboard",
  },
  {
    title: "Masters",
    icon: MdLibraryBooks,
    submenus: [
      { title: "Reporting Entity", path: "/masters/reporting-entity" },
      { title: "Director/KMP Master", path: "/masters/director-kmp" },
      {
        title: "Director/KMP Relative Master",
        path: "/masters/director-kmp-relative",
      },
      {
        title: "Other Related Party Master",
        path: "/masters/other-related-party",
      },
      {
        title: "Entity Controlled by KMP Master",
        path: "/masters/entity-controlled-by-kmp",
      },
      { title: "Sector Master", path: "/masters/sector" },
      { title: "Division Master", path: "/masters/division" },
      { title: "Currency Master", path: "/masters/currency" },
      { title: "Period Master", path: "/masters/period" },
      { title: "Interim Period Master", path: "/masters/interim-period" },
      { title: "CG Period Control", path: "/masters/cg-period-control" },
      {
        title: "Shareholder Approval Amount Master",
        path: "/masters/shareholder-approval-amount",
      },

      { title: "Interim Currency Master", path: "/masters/interim-currency" },
      { title: "Turnover Master", path: "/masters/turnover" },
      { title: "Relationship Master", path: "/masters/relationship" },
      { title: "Transaction Type Master", path: "/masters/transaction-type" },
      {
        title: "Sub Transaction Type Master",
        path: "/masters/sub-transaction-type",
      },
      { title: "User Master", path: "/masters/user" },
      { title: "User CFO Master", path: "/masters/user-cfo" },
      { title: "Mail Config", path: "/masters/mail-config" },
      {
        title: "Related Parties Disclosure",
        path: "/masters/related-parties-disclosure",
      },
      { title: "Group Master", path: "/masters/group-master" },
    ],
  },
  {
    title: "Relationship Mapping",
    icon: FaLink,
    submenus: [
      {
        title: "Director/MKP Mapping",
        path: "/relationship/director-kmp",
      },
      {
        title: "Direct Related Prty Mapping",
        path: "/relationship/direct-related-prty",
      },
      {
        title: "Extended Related Prty Mapping",
        path: "/relationship/extended-related-prty",
      },
      {
        title: "Total Related Parties Mapping List",
        path: "/relationship/total-related-party",
      },
    ],
  },
  {
    title: "Reports",
    icon: MdReport,
    submenus: [
      {
        title: "Related Party Master Export",
        path: "/reports/related-party-master-export",
      },
      { title: "Master Export", path: "/reports/master-export" },
    ],
  },
  {
    title: "Transaction Upload",
    icon: MdUpload,
    submenus: [
      { title: "Invoice Upload", path: "/upload/invoice" },
      { title: "Part AB Upload", path: "/upload/part-ab" },
      { title: "Part AB Group Upload", path: "/upload/part-ab-group" },
      { title: "Estimate Turnover Upload", path: "/upload/estimate-turnover" },
    ],
  },
  {
    title: "Transaction Update",
    icon: MdUpdate,
    submenus: [
      { title: "Part AB Update", path: "/update/part-ab" },
      { title: "Part AB Group Update", path: "/update/part-ab-group" },
      {
        title: "Provision and Probable Tagging",
        path: "/update/provision-probable",
      },
    ],
  },
  {
    title: "Transaction Reports",
    icon: MdOutlineAnalytics,
    submenus: [
      { title: "Invoice Mismatch Report", path: "/reports/invoice-mismatch" },
      { title: "LODR Mismatch Report", path: "/reports/lodr-mismatch" },
      { title: "Part AB Report", path: "/reports/part-ab" },
      { title: " Part A Flat File", path: "/reports/part-a-flat-file" },
      { title: "Part B Flat File", path: "/reports/part-b-flat-file" },
      { title: "XBRL Report", path: "/reports/xbrl" },
      { title: "Estimate Turnover Report", path: "/reports/estimate-turnover" },
      {
        title: "Related Parties Disclosure Report",
        path: "/reports/related-parties",
      },
    ],
  },
  {
    title: "Certificate Upload",
    icon: FaCertificate,
    submenus: [{ title: "Upload Certificate", path: "/certificate/upload" }],
  },
  {
    title: "Logs",
    icon: FaFileAlt,
    submenus: [
      { title: "Related Party Master Logs", path: "/logs/rp-master" },
      { title: "Master Logs", path: "/logs/master" },
    ],
  },
];

export default menuConfig;
