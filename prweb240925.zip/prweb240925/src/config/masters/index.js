import directorKmp from "./directorKmp";
import reportingEntity from "./reportingEntity";

const masterConfigs = {
  reportingEntity,
  directorKmp,
};

export default masterConfigs;
