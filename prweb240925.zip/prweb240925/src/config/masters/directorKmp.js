// src/config/masters/directorKmp.js

const directorKmp = {
  key: "directorKmp",

  title: "Director/KMP Master",

  api: {
    list: "/director/search",

    add: "/director/saveDirector",

    update: "/director/updateDirector",

    delete: "/director/deleteDirector", // confirm with backend
  },

  idField: "id",

  // TABLE COLUMNS

  columns: [
    { label: "Sr No", field: "srNo" },
    { label: "First Name", field: "firstName" },
    { label: "Last Name", field: "lastName" },
    { label: "PAN No", field: "PAN" },
    { label: "Nationality", field: "nationality" },
    { label: "DIN", field: "DIN" },
    { label: "Type", field: "type" },
    { label: "Is Independent Director", field: "isIndependent" },
    { label: "Start Date", field: "startDate" },
    { label: "CESS Date", field: "cessDate" },
    { label: "Director/KMP UIN", field: "directorUIN" },
    { label: "Is Employee of M&M Group", field: "isEmployee" },
    {
      label: "Company Name",
      field: "companyName",
      render: (row) => row.company?.companyName ?? "-",
    },
    {
      label: "Employee ID",
      field: "userID",
      //render: (row) => row.company?.userID ?? "-",
    },
    {
      label: "Remark",
      field: "remark",
      //render: (row) => row.company?.remark ?? "-",
    },
    { label: "Created By", field: "createdBy" },
    { label: "Created On", field: "createdon" },
    { label: "Updated By", field: "updatedBy" },
    { label: "Updated On", field: "modifiedon" },
  ],

  // FORM FIELDS

  fields: [
    {
      name: "nationality",

      label: "Nationality",

      type: "select",

      required: true,

      options: [
        { value: "INDIAN", label: "Indian" },

        { value: "FOREIGN", label: "Foreign" },
      ],
    },

    { name: "PAN", label: "PAN No.", type: "text", required: true },

    { name: "DIN", label: "DIN No.", type: "text" },

    {
      name: "type",

      label: "Type",

      type: "select",

      required: true,

      options: [
        { value: "DIRECTOR", label: "Director" },

        { value: "KMP", label: "KMP" },

        { value: "OTHER PERSON", label: "Other Person" },
      ],
    },

    {
      name: "isIndependent",

      label: "Is Independent",

      type: "select",

      options: [
        { value: "YES", label: "Yes" },

        { value: "NO", label: "No" },
      ],
    },

    { name: "firstName", label: "First Name", type: "text", required: true },

    { name: "lastName", label: "Last Name", type: "text", required: true },

    { name: "directorUIN", label: "Director/KMP UIN", type: "text" },

    {
      name: "isEmployee",

      label: "Is Employee of M&M Group",

      type: "select",

      required: true,

      options: [
        { value: "YES", label: "Yes" },

        { value: "NO", label: "No" },
      ],
    },

    {
      name: "companyId",

      label: "Company",

      type: "select",

      required: true,

      options: [],

      dynamicOptionsApi: "/company/getAllMasterCompany",
    },

    { name: "userID", label: "Employee ID", type: "text", required: true },

    { name: "startDate", label: "Start Date", type: "date", required: true },

    { name: "cessDate", label: "Cease Date", type: "date", required: true },

    { name: "remark", label: "Remark", type: "textarea" },
  ],

  // RULES

  allowFields: {
    create: [
      "nationality",

      "PAN",

      "DIN",

      "type",

      "isIndependent",

      "firstName",

      "lastName",

      "directorUIN",

      "isEmployee",

      "companyId",

      "userID",

      "startDate",

      "cessDate",

      "remark",
    ],

    edit: () => [
      "nationality",

      "PAN",

      "DIN",

      "type",

      "isIndependent",

      "firstName",

      "lastName",

      "directorUIN",

      "isEmployee",

      "companyId",

      "userID",

      "startDate",

      "cessDate",

      "remark",
    ],

    list: true,

    export: true,
  },

  enrichFormFields(fields, { companyOptions }) {
    return fields.map((f) => {
      if (f.name === "companyId") {
        return {
          ...f,

          options: companyOptions.map((c) => ({
            value: c.id,

            label: c.companyName,
          })),
        };
      }

      return f;
    });
  },

  beforeSubmit(record) {
    const payload = { ...record };

    Object.keys(payload).forEach((k) => {
      if (payload[k] === "" || payload[k] === null) delete payload[k];
    });

    // normalize values

    if (payload.PAN) payload.PAN = payload.PAN.toUpperCase();

    if (payload.DIN) payload.DIN = String(payload.DIN).trim();

    if (payload.directorUIN)
      payload.directorUIN = String(payload.directorUIN).trim();

    // map companyId → company object

    if (payload.companyId) {
      payload.company = { id: Number(payload.companyId) };

      delete payload.companyId;
    }

    payload.userId = payload.userId || 101;

    if (!payload.remark) payload.remark = "NA";

    return payload;
  },
};

export default directorKmp;
