// src/config/masters/reportingEntity.js

const reportingEntity = {
  key: "reportingEntity",

  title: "Reporting Entity",

  api: {
    list: "/company/search", // GET

    add: "/company/saveCompany", // POST

    update: "/company/updateCompany", // PUT

    delete: "/company/deleteCompany", // DELETE
  },

  idField: "id",

  // TABLE COLUMNS

  columns: [
    { label: "Sr No", field: "srNo" },

    { label: "Company Name", field: "companyName" },

    { label: "Ownership Type", field: "ownershipType" },

    { label: "PAN No", field: "companyPAN" },

    {
      label: "CIN",

      field: "CIN",

      render: (row) => row.CIN || row.cin || "NA",
    },

    { label: "Country of Origin", field: "countryOfOrigin" },

    { label: "Origin Type", field: "originType" },

    { label: "Hyperion Code", field: "hyperionCode" },

    { label: "Domain", field: "domain" },

    { label: "Company SAP ID", field: "companySAPId" },

    {
      label: "Sector",

      field: "sectorName",

      render: (row) => row.sector?.sector || "-",
    },

    { label: "Company UIN", field: "companyUIN" },

    {
      label: "Currency",

      field: "currencyName",

      render: (row) => row.currency?.currencyName || "-",
    },

    { label: "Listed Group", field: "listedGroup" },

    { label: "Is Listed", field: "islisted" },

    { label: "Incorporation/Acquisition Date", field: "startDate" },

    { label: "Cease Date", field: "cessDate" },

    { label: "Remark", field: "remark" },

    { label: "Created By", field: "createdBy" },

    { label: "Created On", field: "createdAt" },

    { label: "Updated By", field: "updatedBy" },

    { label: "Updated On", field: "updatedAt" },
  ],

  // FORM FIELDS

  fields: [
    {
      name: "originType",

      label: "Origin Type",

      type: "select",

      required: true,

      options: [
        { value: "Domestic", label: "Domestic" },

        { value: "International", label: "International" },
      ],
    },

    {
      name: "companyName",

      label: "Company Name",

      type: "text",

      required: true,

      info: "Full registered name without prefix/suffix (Eg. MAHINDRA AND MAHINDRA LIMITED)",
    },

    {
      name: "countryOfOrigin",

      label: "Country of Origin",

      type: "text",

      required: true,
    },

    {
      name: "ownershipType",

      label: "Ownership Type",

      type: "select",

      required: true,

      options: [
        { value: "Private", label: "Private" },

        { value: "Public", label: "Public" },
      ],
    },

    { name: "companyPAN", label: "PAN No", type: "text", required: true },

    { name: "CIN", label: "CIN", type: "text", required: true },

    { name: "hyperionCode", label: "Hyperion Code", type: "text" },

    {
      name: "domain",

      label: "Domain",

      type: "select",

      required: true,

      options: [
        { value: "Mahindra", label: "Mahindra" },

        { value: "Non-Mahindra", label: "Non-Mahindra" },
      ],
    },

    {
      name: "companySAPId",
      label: "Company SAP ID",
      type: "text",
      required: true,
    },

    {
      name: "sectorId",

      label: "Sector",

      type: "select",

      required: true,

      options: [],

      dynamicOptionsApi: "/sector/getAll",
    },

    {
      name: "companyType",

      label: "Company Type",

      type: "select",

      required: true,

      options: [{ value: "MASTER_COMPANY", label: "Reporting Entity" }],
    },

    {
      name: "currencyId",

      label: "Currency",

      type: "select",

      required: true,

      options: [],

      dynamicOptionsApi: "/currency/getAll",
    },

    { name: "companyUIN", label: "Company UIN", type: "text" },

    {
      name: "listedGroup",

      label: "Listed Group",

      type: "select",

      required: true,

      options: [
        { value: "Group A", label: "Group A" },

        { value: "Group B", label: "Group B" },
      ],
    },

    {
      name: "islisted",

      label: "Is Listed",

      type: "select",

      required: true,

      options: [
        { value: "Yes", label: "Yes" },

        { value: "No", label: "No" },
      ],
    },

    {
      name: "startDate",
      label: "Incorporation Date",
      type: "date",
      required: true,
    },

    { name: "cessDate", label: "Cease Date", type: "date" },

    { name: "remark", label: "Remark", type: "textarea" },
  ],

  // RULES

  allowFields: {
    create: [
      "originType",

      "companyName",

      "countryOfOrigin",

      "ownershipType",

      "companyPAN",

      "CIN",

      "hyperionCode",

      "domain",

      "companySAPId",

      "sectorId",

      "companyType",

      "currencyId",

      "companyUIN",

      "listedGroup",

      "islisted",

      "startDate",

      "cessDate",

      "remark",
    ],

    edit: () => [
      "companyName",

      "ownershipType",

      "domain",

      "sectorId",

      "currencyId",

      "listedGroup",

      "islisted",

      "remark",
    ],

    list: true,

    export: true,
  },

  enrichFormFields(fields, { sectorOptions, currencyOptions }) {
    return fields.map((f) => {
      if (f.name === "sectorId") {
        return {
          ...f,

          options: sectorOptions.map((s) => ({ value: s.id, label: s.sector })),
        };
      }

      if (f.name === "currencyId") {
        return {
          ...f,

          options: currencyOptions.map((c) => ({
            value: c.id,
            label: c.currencyName,
          })),
        };
      }

      return f;
    });
  },

  beforeSubmit(record) {
    const payload = { ...record };

    Object.keys(payload).forEach((k) => {
      if (payload[k] === "" || payload[k] === null) delete payload[k];
    });

    payload.userId = payload.userId || 101;

    if (!payload.remarks) payload.remarks = "NA";

    return payload;
  },
};

export default reportingEntity;
