import { useAuth } from "../../context/AuthContext";

export default function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <h1 className="text-4xl font-bold mb-4">Welcome {user?.name}</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officiis
        ipsa delectus.
      </p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
