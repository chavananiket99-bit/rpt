import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { toast } from "react-toastify";
export default function Login() {
  const { login } = useAuth();
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;
    setLoading(true);

    try {
      await login(credentials);
      toast.success("Login Successful!");
    } catch (err) {
      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        "Login failed. Please check your credentials";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  const handleSSOLogin = () => {
    window.location.href =
      "https://prweb-revamp-dev.m-devsecops.com/api/v1/sso";
  };

  return (
    <div className="flex h-screen">
      {/* Left Panel */}
      <div className="flex-1 bg-[url('/images/login-bg.jpg')] bg-cover bg-right bg-no-repeat hidden md:flex w-1/2 bg-black items-center justify-center relative login-left">
        <div className="absolute">
          <img
            src="/images/mahindra_rise.png"
            className="w-[250px] object-cover h-auto"
          />
        </div>
        <div className="absolute bottom-[180px] left-0 ">
          <img
            src="/images/beam.png"
            className="w-[150px] object-cover h-auto"
          />
        </div>
      </div>
      {/* Right Panel */}
      <div className="flex w-full md:w-1/2 items-center justify-center bg-gradient-to-b from-gray-900 to-black px-6">
        <div className="w-full max-w-md bg-opacity-80 text-white p-8 rounded-lg">
          <h2 className="text-3xl font-semibold mb-2 text-center">Sign In</h2>
          <p className="text-center mb-6">
            Welcome to{" "}
            <span className="font-semibold">PR Web Base Solution</span>
          </p>
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              name="email"
              placeholder="Enter CONT ID / Email"
              value={credentials.email}
              onChange={handleChange}
              className="w-full px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-red-500 rounded-none text-black"
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Enter Password"
              value={credentials.password}
              onChange={handleChange}
              className="w-full px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-red-500 rounded-none text-black"
              required
            />
            <div className="text-right text-sm">
              <a
                href="/forgot-password"
                className="text-white-400 hover:text-red-400 border-b-2"
              >
                Forgot Password?
              </a>
            </div>
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2 rounded-none font-semibold ${
                loading
                  ? "bg-gray-500 cursor-not-allowed"
                  : "bg-red-600 hover:bg-red-700"
              }`}
            >
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>
          {/* SSO Login */}
          <div className="mt-4 text-right text-sm">
            <a
              href="#"
              onClick={handleSSOLogin}
              className="font-semibold border-b-2"
            >
              SSO LOGIN
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
