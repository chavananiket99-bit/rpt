import MasterPage from "../../components/common/MasterPage";
import masterConfigs from "../../config/masters";
//import mastersConfig from "../../config/mastersConfig";

export default function ReportingEntity() {
  return <MasterPage config={masterConfigs.reportingEntity} />;
}
