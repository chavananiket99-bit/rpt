import MasterPage from "../../components/common/MasterPage";
import mastersConfig from "../../config/mastersConfig";

export default function Currency() {
  return <MasterPage {...mastersConfig.currency} />;
}
