import MasterPage from "../../components/common/MasterPage";
import mastersConfig from "../../config/mastersConfig";

export default function OtherRelatedParty() {
  return <MasterPage {...mastersConfig.otherRelatedParty} />;
}
