import MasterPage from "../../components/common/MasterPage";
import masterConfigs from "../../config/masters";

export default function DirectorKmp() {
  return <MasterPage config={masterConfigs.directorKmp} />;
}
