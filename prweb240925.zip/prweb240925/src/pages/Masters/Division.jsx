import MasterPage from "../../components/common/MasterPage";
import mastersConfig from "../../config/mastersConfig";

export default function Division() {
  return <MasterPage {...mastersConfig.division} />;
}
