import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  withCredentials: false,
});

api.interceptors.request.use((config) => {
  try {
    const token = localStorage.getItem("authToken");

    const url = (config.url || "").toString();

    const isLogin = url.includes("/login");

    if (token && !isLogin) {
      if (!config.headers) config.headers = {};

      config.headers["Authorization"] = `Bearer ${token}`;
    }
  } catch (e) {
    console.error("Error reading token", e);
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,

  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem("authToken");

      localStorage.removeItem("authEmail");

      window.location.href = "/";
    }

    return Promise.reject(error);
  }
);

export default api;
