import api from "./axiosConfig";

// all companies (with pagination + search)
export const getAllCompanies = async (page = 0, size = 10) => {
  const response = await api.get(`/company/search`, {
    params: { page, size },
  });

  return response.data;
};

// add a new company
export const addCompany = async (company) => {
  const response = await api.post(`/saveCompany`, company);

  return response.data;
};

// update an existing company
export const updateCompany = async (company) => {
  const response = await api.post(`/updateCompany`, company);

  return response.data;
};

// delete company (assuming backend has this endpoint)
export const deleteCompany = async (id) => {
  const response = await api.delete(`/company/delete/${id}`);

  return response.data;
};

// others (if needed)
export const getAllCopy = async () => {
  const res = await api.get(`/company/getAllCopy`);

  return res.data;
};

export const getNewRequest = async () => {
  const res = await api.get(`/company/newRequest`);

  return res.data;
};
