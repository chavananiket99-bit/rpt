import api from "./axiosConfig";

// all directors (with pagination + search)
export const getAllDirectors = async (page = 0, size = 10) => {
  const response = await api.get(`/director/search`, {
    params: { page, size },
  });

  return response.data;
};

// add a new director
export const addDirector = async (director) => {
  const response = await api.post(`/saveDirector`, director);

  return response.data;
};

// update an existing director
export const updateDirector = async (director) => {
  const response = await api.post(`/updateDirector`, director);

  return response.data;
};

// delete company (assuming backend has this endpoint)
export const deleteDirector = async (id) => {
  const response = await api.delete(`/director/delete/${id}`);

  return response.data;
};
