import api from "./axiosConfig";
export const loginUser = async (credentials) => {
  try {
    const res = await api.post("/login", {
      email: credentials.email,
      password: credentials.password,
    });
    return res.data;
  } catch (err) {
    if (err.response) {
      const status = err.response.status;
      const serverMsg = err.response.data?.message || err.response.data || null;
      if (status === 401 || status === 403) {
        throw new Error(serverMsg || "Invalid email or password");
      }
      if (status === 503) {
        throw new Error("Service unavailable. Please try again later.");
      }
      throw new Error(serverMsg || `Request failed with status ${status}`);
    } else if (err.request) {
      throw new Error("No response from server. Please check your network.");
    } else {
      throw new Error("Unexpected error: " + err.message);
    }
  }
};
export const getProfile = async () => {
  const res = await api.get("/auth/me");
  return res.data;
};
export const uploadMasterFile = (endpoint, file) => {
  const fd = new FormData();
  fd.append("file", file);
  return api.post(`/masters/${endpoint}/upload`, fd, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};
