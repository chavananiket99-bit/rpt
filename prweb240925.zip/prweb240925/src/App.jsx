import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";

import Login from "./pages/Auth/Login";

import Dashboard from "./pages/Dashboard/Dashboard";
import Layout from "./components/layout/Layout";
import PrivateRoute from "./components/auth/PrivateRoute";
import ReportingEntity from "./pages/Masters/ReportingEntity";
import DirectorKmp from "./pages/Masters/DirectorKmp";
import DirectorKmpRelative from "./pages/Masters/DirectorKmpRelative";
import OtherRelatedParty from "./pages/Masters/OtherRelatedParty";
import EntityControlledByKmp from "./pages/Masters/EntityControlledByKmp";
import Sector from "./pages/Masters/Sector";
import Division from "./pages/Masters/Division";
import { ToastContainer } from "react-toastify";
import Currency from "./pages/Masters/Currency";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Login />} />

        <Route element={<PrivateRoute />}>
          <Route element={<Layout />}>
            {/* Dashboard */}
            <Route path="/dashboard" element={<Dashboard />} />

            {/* Masters */}
            <Route
              path="/masters/reporting-entity"
              element={<ReportingEntity />}
            />
            <Route path="/masters/director-kmp" element={<DirectorKmp />} />
            <Route
              path="/masters/director-kmp-relative"
              element={<DirectorKmpRelative />}
            />
            <Route
              path="/masters/other-related-party"
              element={<OtherRelatedParty />}
            />
            <Route
              path="/masters/entity-controlled-by-kmp"
              element={<EntityControlledByKmp />}
            />
            <Route path="/masters/sector" element={<Sector />} />
            <Route path="/masters/division" element={<Division />} />
            <Route path="/masters/currency" element={<Currency />} />
          </Route>
        </Route>
      </Routes>
      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
}
export default App;
