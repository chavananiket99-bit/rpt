import { useEffect, useState } from "react";
import {
  FaPlus,
  FaEdit,
  FaTrash,
  FaDownload,
  FaFileExport,
  FaInfoCircle,
} from "react-icons/fa";
import api from "../../api/axiosConfig";

// Normalize date
const normalizeDate = (dateStr) => {
  if (!dateStr) return "";
  if (dateStr.includes("-")) {
    const parts = dateStr.split("-");
    if (parts.length === 3 && parts[2].length === 4) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`; // DD-MM-YYYY → YYYY-MM-DD
    }
  }

  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return "";
  return d.toISOString().split("T")[0];
};

export default function MasterPage({ config }) {
  const { title, api: apiConfig = {}, fields = [], columns = [] } = config;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({});
  const [tableData, setTableData] = useState([]);
  const [search, setSearch] = useState("");
  const [fileToUpload, setFileToUpload] = useState(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(1);
  const [totalElements, setTotalElements] = useState(0);

  // dropdown state
  const [sectorOptions, setSectorOptions] = useState([]);
  const [currencyOptions, setCurrencyOptions] = useState([]);
  const [companyOptions, setCompanyOptions] = useState([]);

  const loadData = async (opts = {}) => {
    if (!apiConfig.list) return;
    setLoading(true);
    try {
      const params = {
        page: page - 1,
        size: pageSize,
        q: search || "",
        ...opts.params,
      };
      const res = await api.get(apiConfig.list, { params });

      let raw =
        res.data?.data?.paginatedData ||
        res.data?.content ||
        res.data?.items ||
        (Array.isArray(res.data?.data) ? res.data.data : null) ||
        res.data?.data ||
        [];

      if (!Array.isArray(raw)) {
        if (res.data?.data && typeof res.data.data === "object") {
          raw = res.data.data.paginatedData || [];
        } else {
          raw = [];
        }
      }

      const data = raw.map((item) => ({
        ...item,
        CIN: item.CIN || item.cin || "",
        sectorName: item.sector?.sector || item.sectorName || "-",
        currencyName: item.currency?.currencyName || item.currencyName || "-",
      }));

      setTableData(data);
      setTotalPages(res.data?.data?.totalPages ?? res.data?.totalPages ?? 1);
      setTotalElements(
        res.data?.data?.totalElements ??
          res.data?.totalElements ??
          data.length ??
          0
      );
    } catch (err) {
      console.error("Error fetching data:", err);
      setTableData([]);
      setTotalPages(1);
      setTotalElements(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [apiConfig, page, pageSize]);

  // fetch dropdowns (generic: looks for dynamicOptionsApi in fields)
  useEffect(() => {
    const fetchDropdowns = async () => {
      try {
        for (const f of fields) {
          if (f.dynamicOptionsApi) {
            const res = await api.get(f.dynamicOptionsApi).catch(() => ({
              data: { data: [] },
            }));

            const options = res.data?.data || [];
            if (f.name === "companyId") setCompanyOptions(options);
            if (f.name === "sectorId") setSectorOptions(options);
            if (f.name === "currencyId") setCurrencyOptions(options);
          }
        }
      } catch (err) {
        console.error("Failed to load dropdowns", err);
      }
    };
    fetchDropdowns();
  }, [fields]);

  const handleFormChange = (name, value) => {
    let updatedForm = { ...formData, [name]: value };

    if (name === "originType") {
      if (value === "Domestic" || value === "domestic") {
        updatedForm.countryOfOrigin = "India";
        if (updatedForm.companyPAN === "NA") updatedForm.companyPAN = "";
        if (updatedForm.CIN === "NA") updatedForm.CIN = "";
      } else if (value === "International" || value === "international") {
        updatedForm.companyPAN = "NA";
        updatedForm.CIN = "NA";
        if (updatedForm.countryOfOrigin === "India")
          updatedForm.countryOfOrigin = "";
      }
    }

    if (["sectorId", "currencyId", "companyId"].includes(name)) {
      setFormData((p) => ({ ...p, [name]: String(value) }));
    } else {
      setFormData((p) => ({ ...p, [name]: value }));
    }

    setFormData(updatedForm);
  };

  const handleUploadFile = async () => {
    if (!fileToUpload) return alert("Select a file first");
    alert("File upload placeholder — wire to backend.");
    setFileToUpload(null);
  };

  const handleDownload = async () => {
    try {
      alert("Download placeholder");
    } catch (err) {
      console.error("Download failed", err);
      alert("Download failed");
    }
  };

  const handleExport = () => {
    alert("Export placeholder");
  };

  const openModal = (item = null) => {
    setEditingItem(item);
    if (item) {
      setFormData({
        ...item,
        originType: item.originType
          ? item.originType.charAt(0) + item.originType.slice(1).toLowerCase()
          : "",
        ownershipType: item.ownershipType
          ? item.ownershipType.charAt(0) +
            item.ownershipType.slice(1).toLowerCase()
          : "",
        domain: item.domain
          ? item.domain.charAt(0).toUpperCase() +
            item.domain.slice(1).toLowerCase()
          : "",
        sectorId: item.sector?.id ? String(item.sector.id) : "",
        currencyId: item.currency?.id ? String(item.currency.id) : "",
        companyId: item.company?.id ? String(item.company.id) : "",
        startDate: normalizeDate(item.startDate),
        cessDate: normalizeDate(item.cessDate),
        remark: item.remark || "",
      });
    } else {
      setFormData({});
    }
    setClosing(false);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setClosing(true);
    setTimeout(() => {
      setEditingItem(null);
      setFormData({});
      setIsModalOpen(false);
      setClosing(false);
    }, 300);
  };

  const submitForm = async (e) => {
    if (e) e.preventDefault();
    try {
      let payload = { ...formData };

      // Let config handle preprocessing
      if (config.beforeSubmit) {
        payload = config.beforeSubmit(payload, editingItem ? "edit" : "create");
      }

      let res;
      if (editingItem && apiConfig.update) {
        payload.id = editingItem.id;
        res = await api.put(apiConfig.update, payload);
      } else if (apiConfig.add) {
        delete payload.id;
        res = await api.post(apiConfig.add, payload);
      }

      if (res?.data?.message) {
        alert(res.data.message);
      } else {
        alert("Saved successfully");
      }

      setPage(1);
      await loadData();
      setTimeout(() => loadData(), 800);

      closeModal();
    } catch (err) {
      console.error("Save failed:", err.response?.data || err);
      alert(err?.response?.data?.message || "Save Failed");
    }
  };

  const handleDelete = async (item) => {
    if (!confirm("Are you sure to delete?")) return;
    try {
      if (apiConfig.delete) {
        await api.delete(`${apiConfig.delete}/${item.id}`);
      }
      await loadData();
    } catch (err) {
      console.error("Delete failed:", err);
      alert("Delete failed");
    }
  };

  const filteredData = tableData.filter((row) =>
    Object.values(row).join(" ").toLowerCase().includes(search.toLowerCase())
  );

  // --- NEW: generic allowFields + enrichFormFields ---
  const allowed =
    typeof config.allowFields?.[editingItem ? "edit" : "create"] === "function"
      ? config.allowFields[editingItem ? "edit" : "create"]()
      : config.allowFields?.[editingItem ? "edit" : "create"] ||
        fields.map((f) => f.name);

  let enrichedFormFields = fields.filter((f) => allowed.includes(f.name));

  if (config.enrichFormFields) {
    enrichedFormFields = config.enrichFormFields(enrichedFormFields, {
      sectorOptions,
      currencyOptions,
      companyOptions,
      editingItem,
    });
  }

  return (
    <div className="bg-white rounded shadow p-2">
      {/* Header */}
      <div className="flex flex-col">
        <div className="flex justify-between">
          <h1 className="text-base md:text-sm font-semibold">{title}</h1>
          <button
            onClick={() => openModal()}
            className="bg-[#e31837] text-white px-3 py-1 flex items-center gap-2 text-xs"
          >
            <FaPlus /> ADD
          </button>
        </div>

        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mt-2 mb-2">
          <div className="flex flex-wrap items-center gap-2">
            {config.extraTopButtons?.map((b, idx) => (
              <button
                key={idx}
                onClick={b.onClick}
                className="px-3 py-1 rounded bg-gray-200"
              >
                {b.label}
              </button>
            ))}

            <button
              onClick={handleDownload}
              className="bg-gray-700 text-white px-3 py-1 flex items-center gap-2 text-sm"
            >
              <FaDownload /> Download Excel
            </button>

            <div className="flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-2 bg-white border px-3 py-1 cursor-pointer">
                <input
                  type="file"
                  onChange={(e) => setFileToUpload(e.target.files?.[0] ?? null)}
                  className="hidden"
                />
                <span className="text-sm">Choose File</span>
              </label>
              {fileToUpload && (
                <div className="flex items-center gap-2 text-xs border px-2 py-1 max-w-full sm:max-w-[200px]">
                  <span className="truncate flex-1">{fileToUpload.name}</span>
                  <button
                    type="button"
                    onClick={() => setFileToUpload(null)}
                    className="text-red-600 font-bold"
                  >
                    X
                  </button>
                </div>
              )}
              <button
                onClick={handleUploadFile}
                className="bg-red-600 text-white px-3 py-1 text-sm"
              >
                Upload Excel
              </button>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleExport}
              className="bg-black text-white px-3 py-1 text-sm flex items-center gap-2"
            >
              <FaFileExport /> Export
            </button>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center mb-1">
        <div className="flex items-center gap-2 text-xs">
          <span>Show</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
            className="border px-2 py-1 text-xs"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span>entries</span>
        </div>
        <input
          placeholder="Search..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              setPage(1);
              loadData();
            }
          }}
          className="border px-2 py-1 text-xs"
        />
      </div>

      {/* Table */}
      {loading ? (
        <div className="text-center p-6">Loading...</div>
      ) : (
        <div className="overflow-x-auto border rounded">
          <div className="max-h-[60vh] overflow-y-auto">
            <table className="min-w-[900px] w-full border-collapse text-sm table-auto">
              <thead className="bg-gray-200 sticky top-0 z-10">
                <tr>
                  {columns.map((c) => (
                    <th
                      key={c.field}
                      className="border px-2 py-1 text-left text-xs whitespace-nowrap"
                    >
                      {c.label}
                    </th>
                  ))}
                  <th className="border px-2 py-1 text-xs text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length ? (
                  filteredData.map((row, rIdx) => (
                    <tr
                      key={row.id ?? rIdx}
                      className="odd:bg-white even:bg-gray-50"
                    >
                      {columns.map((c, i) => (
                        <td
                          key={i}
                          className="border px-2 py-1 text-xs whitespace-nowrap"
                        >
                          {c.field === "srNo"
                            ? (page - 1) * pageSize + (rIdx + 1)
                            : c.render
                            ? c.render(row)
                            : row[c.field] ?? "-"}
                        </td>
                      ))}
                      <td className="border px-2 py-1 text-center">
                        <button
                          onClick={() => openModal(row)}
                          className="text-blue-600 mr-2"
                        >
                          <FaEdit />
                        </button>
                        <button
                          onClick={() => handleDelete(row)}
                          className="text-red-600"
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={columns.length + 1}
                      className="text-center py-6"
                    >
                      No records found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      <div className="flex justify-between items-center mt-3">
        <div className="text-xs">
          Page {page} of {totalPages} | Total records: {totalElements}
        </div>
        <div className="flex gap-2">
          <button
            disabled={page === 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-3 py-1 border text-xs disabled:opacity-50"
          >
            Prev
          </button>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="px-3 py-1 border text-xs disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div
          className={`fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 transition-opacity duration-300 ${
            closing ? "animate-fadeOut" : "animate-fadeIn"
          }`}
        >
          <div
            className={`bg-white w-full max-w-4xl h-[90vh] rounded shadow-lg flex flex-col transform transition-all duration-300 ${
              closing ? "animate-slideDown" : "animate-slideUp"
            }`}
          >
            <div className="flex justify-between items-center px-4 py-3 bg-black text-white flex-shrink-0">
              <h2 className="text-base md:text-lg font-semibold">
                {editingItem ? "Edit" : "Add"} {title}
              </h2>
              <button onClick={closeModal} className="text-gray-300">
                ✕
              </button>
            </div>

            <div id="master-modal-body" className="p-6 overflow-y-auto flex-1">
              <form
                id="masterForm"
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
                onSubmit={submitForm}
              >
                {enrichedFormFields.map((f) => (
                  <div key={f.name} className="flex flex-col">
                    <label className="mb-1 text-sm font-medium flex items-center gap-1">
                      {f.label}
                      {f.required && <span className="text-red-500">*</span>}
                      {f.info && (
                        <span className="relative group cursor-pointer inline-flex">
                          <FaInfoCircle className="text-red-500 text-xs" />
                          <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 w-max max-w-xs z-10 opacity-0 scale-95 pointer-events-none group-hover:opacity-100 group-hover:scale-100 transition-all duration-200 ease-out">
                            {f.info}
                            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black rotate-45"></div>
                          </div>
                        </span>
                      )}
                    </label>

                    {f.type === "date" ? (
                      <input
                        type="date"
                        value={formData[f.name] ?? ""}
                        onChange={(e) =>
                          handleFormChange(f.name, e.target.value)
                        }
                        required={!!f.required}
                        className="border px-2 h-10 text-sm"
                      />
                    ) : f.type === "select" ? (
                      <select
                        value={formData[f.name] ?? ""}
                        onChange={(e) =>
                          handleFormChange(f.name, e.target.value)
                        }
                        required={!!f.required}
                        className="border px-2 h-10 text-sm"
                      >
                        <option value="">Select</option>
                        {f.options?.map((o) =>
                          typeof o === "string" ? (
                            <option key={o} value={o}>
                              {o}
                            </option>
                          ) : (
                            <option key={o.value} value={o.value}>
                              {o.label}
                            </option>
                          )
                        )}
                      </select>
                    ) : f.type === "textarea" ? (
                      <textarea
                        value={formData[f.name] ?? ""}
                        onChange={(e) =>
                          handleFormChange(f.name, e.target.value)
                        }
                        required={!!f.required}
                        className="border px-2 py-2 text-sm"
                      />
                    ) : (
                      <input
                        type={f.type || "text"}
                        value={formData[f.name] ?? ""}
                        onChange={(e) =>
                          handleFormChange(f.name, e.target.value)
                        }
                        required={!!f.required}
                        className="border px-2 h-10 text-sm disabled:bg-gray-100 disabled:text-gray-500"
                        disabled={
                          (f.name === "countryOfOrigin" &&
                            formData.originType === "Domestic") ||
                          ((f.name === "companyPAN" || f.name === "CIN") &&
                            formData.originType === "International")
                        }
                      />
                    )}
                  </div>
                ))}
              </form>
            </div>

            <div className="flex justify-end gap-2 px-4 py-3 border-t">
              <button
                type="button"
                onClick={closeModal}
                className="px-4 py-2 bg-gray-300 text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="masterForm"
                className="px-4 py-2 bg-red-600 text-white text-sm"
              >
                {editingItem ? "Update" : "Add"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
