import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import menuConfig from "../../config/menuConfig";
import { FaChevronDown } from "react-icons/fa";

export default function Sidebar({ isOpen }) {
  const [openMenu, setOpenMenu] = useState();
  const location = useLocation();

  const toggleMenu = (title) => {
    setOpenMenu(openMenu === title ? null : title);
  };

  return (
    <aside
      className={`fixed top-14 left-0 h-[calc(100vh-64px)] bg-black text-white w-64 transform transition-transform duration-300 z-30 ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      } `}
    >
      <nav className="p-2 overflow-y-auto h-full">
        {menuConfig.map((menu, idx) => (
          <div key={idx} className="mb-1">
            {menu.submenus ? (
              <>
                <button
                  onClick={() => toggleMenu(menu.title)}
                  className={`flex items-center w-full p-2 rounded hover:bg-gray-700 justify-between text-xs ${
                    openMenu === menu.title ? "bg-gray-700" : ""
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    {menu.icon && <menu.icon size={18} />}
                    <span className="">{menu.title}</span>
                  </div>
                  <FaChevronDown
                    className={`transition-transform duration-300 ${
                      openMenu === menu.title ? "rotate-180" : ""
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openMenu === menu.title ? "max-h-max" : "max-h-0"
                  }`}
                >
                  {menu.submenus.map((sub, subIdx) => (
                    <Link
                      key={subIdx}
                      to={sub.path}
                      className={`block px-6 py-2 text-xs mt-1 hover:bg-gray-600 ${
                        location.pathname === sub.path ? "bg-gray-700" : ""
                      }`}
                    >
                      {sub.title}
                    </Link>
                  ))}
                </div>
              </>
            ) : (
              <Link
                to={menu.path}
                className={`flex items-center p-2 hover:bg-gray-700 text-sm ${
                  location.pathname === menu.path ? "bg-gray-700" : ""
                }`}
              >
                {menu.icon && <menu.icon size={18} className="mr-2" />}
                {menu.title}
              </Link>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
}
