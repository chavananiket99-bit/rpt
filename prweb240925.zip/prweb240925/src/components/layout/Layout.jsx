import { useEffect, useState } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { Outlet } from "react-router-dom";

export default function Layout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const isMobile = window.innerWidth < 768;

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(true);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar isOpen={isSidebarOpen} />
      <div className="flex flex-col flex-1 overflow-x-hidden h-screen">
        <Header toggleSidebar={toggleSidebar} />
        <main
          className={`mt-14 transition-all duration-300 ${
            isSidebarOpen ? "ml-64" : "ml-0"
          } p-4 h-[calc(100vh-56px)]`}
          style={{
            height: "calc(100vh - 64px)",
            marginLeft: !isMobile && isSidebarOpen ? "16rem" : "0",
          }}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}
