import { createContext, useContext, useState } from "react";
import { loginUser } from "../api/userService";
import { useNavigate } from "react-router-dom";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();
  const [user, setUser] = useState(() => {
    const storedToken = localStorage.getItem("authToken");
    const storedEmail = localStorage.getItem("authEmail");
    return storedToken && storedEmail
      ? { email: storedEmail, token: storedToken }
      : null;
  });

  const login = async (credentials) => {
    const data = await loginUser(credentials);

    const token = data?.token || data?.data?.token;

    if (token) {
      const userData = { email: credentials.email, token };
      setUser(userData);

      localStorage.setItem("authToken", token);
      localStorage.setItem("authEmail", credentials.email);

      navigate("/dashboard");
      return userData;
    } else {
      throw new Error(
        data?.message || "Invalid login response - Token missing"
      );
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("authToken");
    localStorage.removeItem("authEmail");
    navigate("/");
  };
  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
export const useAuth = () => useContext(AuthContext);
